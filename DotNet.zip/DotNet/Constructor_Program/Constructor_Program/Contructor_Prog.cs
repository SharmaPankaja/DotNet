﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Program
{
    public class Contructor_Prog
    {
        public int Id;
        public double Weight;
        public string Name;
        readonly string Result;

        //here we declare or create default constructor
        public Contructor_Prog()
        {
            
            Console.WriteLine("This is default constructor..");
            //Console.WriteLine("Enter marks in C..");
            int C = 90;
            //Console.WriteLine("Enter marks in Cpp..");
            int Cpp = 89;
           // Console.WriteLine("Enter marks in DSA..");
            int DSA = 70;
            int per = (C+Cpp+DSA)*100/300;
            if (per > 80 || per==100)
            {
                Result = "Distinction";
                Console.WriteLine(" The result is.." + Result);
                Console.WriteLine(" Percentage obtained :" + per);
            }
            else if(per<80 || per >=35)
            {
                Result= "Pass";
                Console.WriteLine(" The result is.." + Result);
                Console.WriteLine(" Percentage obtained :" + per);
            }
            else
            {
                Result = "Fail";
                Console.WriteLine(" The result is.." + Result);
                Console.WriteLine(" Percentage obtained :" + per);
            }
        }

    }

   /* class construct
    {
        static void Main(string[] args)
        {
            Contructor_Prog cp = new Contructor_Prog();
        }
    }*/
}
