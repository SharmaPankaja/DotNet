﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Program
{
    public class Pizza
    {
        public int Slice;
        public string Name;
        public string Stuffing;
        public Pizza(int slice, string name, string stuffing)
        {
            this.Slice = slice;
            this.Name = name;
            this.Stuffing = stuffing;
            Console.WriteLine("Pizza is readyy..");
        }

        public Pizza(Pizza pi)
        {
            Slice = pi.Slice;
            Name = pi.Name;
            Stuffing = pi.Stuffing;
            Console.WriteLine("This is copy contructor");
        }
        public void Deliver()
        {
            Console.WriteLine("Pizza delivered..");
        }
    }
   /* public class PizzaShop
    {
        static void Main(string[] args)
        {
            Pizza p = new Pizza(6, "Tandoori", "Paneer");
           // p.Deliver();
            Pizza p1 = new Pizza(p);
            p1.Deliver();

        }
    }*/

}
    
