﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Program
{
    public class PrivateConstExample
    {
        public static string OvenStatus;

        private PrivateConstExample()
        {
            OvenStatus = "Ready to Bake..";
        }

        public void BakePizza(string pizzaName) {
            Console.WriteLine(pizzaName+" Pizza is ready..");
        }

        static void main(string[] args) { 
          PrivateConstExample ex = new PrivateConstExample();      
        
        }
    }
}
