﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Program
{
    public class Program
    {
        /*public int Id;
        public double Weight;
        public string Name;
        public bool Result;*/

        /* copy constructor
         * public int RollNumber;
        public string Name;*/

        //static variables
        public static string DefaultSize;
        public static string DefaultCrust;
        public static string size;
        public static string crust;

        //static contructor
        static Program()
        {
            //initialize static values
            DefaultSize = "Medium";
            DefaultCrust = "Thin Crust";

            Console.WriteLine(DefaultSize+DefaultCrust);
        }

        //para constuctor
        public Program(string size,string crust)
        {
            Program.crust = crust;
            Program.size = size;
        }

        public void Display_Pizza()
        {
            Console.WriteLine("The method is called..");
        }

        /*//copy constructor
        public Program(int rollNumber,string name) {
            *//* Console.WriteLine(Id);
             Console.WriteLine(Weight);
             Console.WriteLine(Name);
             Console.WriteLine(Result);*//*
            // Console.WriteLine("This is default constructor");

            *//* //copy constructor
             this.RollNumber = rollNumber;
             this.Name = name;
             Console.WriteLine("This is parameterised constructor");*//*
        }
*/
        //copy constructor
        /*public Program (Program pr)
        {
            *//*RollNumber = pr.RollNumber;
            Name = pr.Name;*//*

        }*/

       /* public void Display()
        {
            Console.WriteLine("This is our method calling");
        }*/
    }

    public class Program2
    {
        /*static void Main(string[] args)
        {
            Program p = new Program("Large", "Cheese");
            p.Display_Pizza();
            Program p2 = new Program(Program.DefaultSize, Program.DefaultCrust);    
            p2.Display_Pizza();
           
        }*/
    }
}
