﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constructor_Program
{
    public class StaticExample
    {
        public static int age;
        public static string education;
        public static int Age;
        public static string Education;

        static StaticExample()
        {
            age = 18;
            education = "Graduate Engineer";
            Console.WriteLine("Age =" + age + " and Education =" + education);
        }

        public StaticExample(int Age,string Education)
        {
            StaticExample.age=Age;
            StaticExample.education = Education;
            Console.WriteLine("Age =" + age + " and Education =" + education);
        }

        public void Display()
        {
            Console.WriteLine("Eligible to take admission in Cdac..");
        }
    }

    public class Admission
    {
        /*static void Main(string[] args) {
            StaticExample se = new StaticExample(23,"Post Grdauated MCA");
            se.Display();
            StaticExample se2 = new StaticExample(StaticExample.age,StaticExample.education);
            se.Display();
        }*/
    }
}
