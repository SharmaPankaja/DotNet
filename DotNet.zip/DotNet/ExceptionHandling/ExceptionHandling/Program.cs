﻿using System;

namespace ExceptionHandling
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }

        public User(string username, string password)
        {
            Username = username;
            Password = password;
        }

        public bool CheckCredentials(string username, string password)
        {
            return Username == username && Password == password;
        }

        public string RecoverPassword(string username)
        {
            if (Username == username)
                return Password;

            throw new Exception("Invalid Username! Cannot recover password..");
        }
    }

    public class LoginSystem
    {
        static void Main(string[] args)
        {
            User user = new User("Pankaja", "sharma123");

            bool exit = false;

            while (!exit)
            {
                try
                {
                    Console.WriteLine("Enter your choice");
                    Console.WriteLine("1.Login  2.Forgot Password  3.Exit");
                    int choice = int.Parse(Console.ReadLine());

                    if (choice < 1 || choice > 3)
                    {
                        throw new Exception("Invalid choice! Please choose a valid option.");
                    }

                    switch (choice)
                    {
                        case 1:
                            try
                            {
                                Console.WriteLine("========Welcome to Login Window========");
                                Console.WriteLine("Enter Username");
                                string username = Console.ReadLine();
                                Console.WriteLine("Enter Password");
                                string password = Console.ReadLine();

                                if (user.CheckCredentials(username, password))
                                {
                                    Console.WriteLine("Login successful!");
                                }
                                else
                                {
                                    throw new Exception("Invalid credentials. Please try again.");
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine("Error Occured"+ex.Message);
                            }
                            break;

                        case 3:
                            exit = true;
                            Console.WriteLine("==Thanks for visiting==");
                            break;

                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error Occured "+ex.Message);
                }
            }
        }
    }
}
