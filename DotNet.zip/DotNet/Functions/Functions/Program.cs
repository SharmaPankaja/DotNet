﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Functions
{
    public class Program
    {
        static int a = 10;
        static int b = 20; 
        static int d = 30;

        static void Main(string[] args)
        {
            int c = a + b;
            int e = b * d;
            Console.WriteLine(a +" + "+ b + " = " + c);
            Console.WriteLine(b + " * " + d + " = " + e);
        }                       
    }
}
