﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class BankName
    {
        public void bank()
        {
            Console.WriteLine("================ICICI Bank===================");
        }
    }
    interface ICICI
    {
        void Userpin(int pin);
    }
    
    interface debit
    {
        bool withdraw(int money);
    }
     class ATM : BankName,ICICI, debit
    {
        public int money;
        public int pin;
        public bool result;

        public void insertCard()
        {
            Console.WriteLine("Card inserted..");
        }

        public void Userpin(int pin)
        {
            
            Console.WriteLine("Enter the pin");
            if (pin != 3434)
            {
                result = false;
                Console.WriteLine("Pin entered is incorrect..Please try again!!");
            }
            else
            {
                result = true;  
                Console.WriteLine("Pin entered successfully");
            }
        }

        public bool withdraw(int money)
        {
            if(money > 8000 || money<=0)
            {
                result = false;
                Console.WriteLine("Insufficient balance or entered amount is wrong..");
                return result;
            }
            else
            {
                result = true;
                Console.WriteLine("Amount " + money + " withdrawed successfully..");
                return result;
            }
            
        }
    }

    class Cust
    {
        /*static void Main(string[] args)
        {
            ATM atm = new ATM();
            atm.insertCard();
            atm.bank();
            atm.Userpin(3434);

            if (atm.result == true)
            {
                atm.withdraw(5000);
            }
            else
            {
                Console.WriteLine("pin entered is incorrect..");
            }

        }*/
    }
}
