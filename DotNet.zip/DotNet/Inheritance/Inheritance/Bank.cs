﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Bank
    {
        private decimal balance;
        //create public method to add money

        public void Deposit(decimal amount)
        {
            if (amount > 0)
            {
                balance += amount;
                Console.WriteLine("Amount is added");
            }
            else
            {
                Console.WriteLine("Invalid deposit amount");
            }
        }
        //if we want to check balance
        public decimal GetBalance()
        {
            return balance;
        }
    }
     class Account : Bank
    {
        
    }
}
