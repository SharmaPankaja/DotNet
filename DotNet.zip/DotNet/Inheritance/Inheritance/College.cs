﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class College
    {
        public void departments()
        {
            Console.WriteLine("Total 5 departments");
        }
    }

    class Faculty : College
    {
        public void totFaculty()
        {
            Console.WriteLine("Total 20 faculties");
        }
    }

    /*class Teacchers : College
    {
        public void teacher()
        {
            Console.WriteLine("These are the set of faculties");
        }
    }*/
    class Students : Faculty
    {
        public void totStudents()
        {
            Console.WriteLine("Total 500 students..");
        }
    }

    class Faculties
    {
        /*static void Main(string[] args)
        {
            Students s = new Students();
            s.departments();
            s.totFaculty();
            s.totStudents();
           
        }*/
    }
}
