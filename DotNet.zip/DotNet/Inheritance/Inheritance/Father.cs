﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Father
    {
        public void FathersAccount()
        {
            Console.WriteLine("20Lakh");
        }
    }


    class Child : Father
    {
        public void ChildsAccount()
        {
            Console.WriteLine("10Thousand");
        }
    }

    class Lawyer
    {
       /* static void Main(string[] args)
        {
            Child ch = new Child();
            ch.FathersAccount();
            ch.ChildsAccount();
        }*/
    }
}
