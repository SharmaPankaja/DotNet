﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    
    public class University
    {
        public void InstUniversity(string uni)
        {
            Console.WriteLine("this is the "+uni+" university");
        }

    }
    class Computers : University
    {
        public void CsDept()
        {
            Console.WriteLine("This is CS It department");
        }
    }
    class Mechanics : University
    {
        public void MechanicalDept()
        {
            Console.WriteLine("This is Mechanical department");
        }
    }

    class Institute : University
    {
       
        public void College(string clg)
        {
            Console.WriteLine("Welcome to the institute..");
        }
    }

    class Collegestd
    {
        /*static void Main(string[] args)
        {
            Institute u = new Institute();
            u.College("MetNashik");
            u.InstUniversity("Nashik");
            Computers c = new Computers();
            c.InstUniversity("SRTMUN");
            c.CsDept();
            Mechanics m = new Mechanics();
            m.InstUniversity("Government");
            m.MechanicalDept();
        }*/
    }

}
