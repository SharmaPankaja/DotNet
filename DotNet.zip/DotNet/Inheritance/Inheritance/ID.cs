﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    interface GovOfIndia
    {
        void GovLaw();
    }
    interface Jio :GovOfIndia
    {
        void Identity();
    }
    interface AdharCard : GovOfIndia
    {
        void Telecom();
    }
    public class PoliceStation : Jio, AdharCard

    {
        public void GovLaw()
        {
            Console.WriteLine("This is Government Law ");
        }

        public void Identity()
        {
            Console.WriteLine("This is Adhar ");
        }

        public void Telecom()
        {
            Console.WriteLine("This is Jio ");
        }

        static void Main(string[] args)
        {
            PoliceStation p = new PoliceStation();
            p.Telecom();
            p.Identity();
            p.GovLaw();
        }
    }
}
