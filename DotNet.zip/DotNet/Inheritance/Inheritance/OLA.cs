﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    public class Google
    {
      public  void maploc() {
            Console.WriteLine("Location mapped successfully");
        }
    }
    interface payment
    {
       
        void PayWithPaytm();
    }
    interface map
    {
        void trackLoc();
        void searchLoc();
    }

    interface contact
    {
        void callCust();
    }

     class OLA : Google,payment, map, contact
    {
        public void BookRide()
        {
            Console.WriteLine("Book a ride");
        }

        public void callCust()
        {
            Console.WriteLine("Call the customer..");
        }

        public void PayWithPaytm()
        {
            Console.WriteLine("Pay..");
        }

        public void searchLoc()
        {
            Console.WriteLine("Search for the location");
        }

        public void trackLoc()
        {
            Console.WriteLine("Tracking the location");
        }
    }

    class User
    {
        /*static void Main(string[] args)
        {
            OLA user = new OLA();
            user.BookRide();
            user.searchLoc();
            user.callCust();
            user.maploc();
            user.trackLoc();
            user.PayWithPaytm();
        }*/


    }

}
