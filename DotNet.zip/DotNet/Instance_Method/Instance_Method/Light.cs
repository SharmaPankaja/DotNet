﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Instance_Method
{
    public class Light
    {
        //instance methods

        public void OnButton()
        {
            Console.WriteLine("Light is On");
        }

         public Light()
        {
            Console.WriteLine("Light is Off");
        }


        /* public static void Insta()
         {
             Console.WriteLine("Profile displayed..");
         }*/
    }

    public class Bank
    {
        public void Credit()
        {
            Console.WriteLine("Money credited to your account..");
        }

        public void Transfer()
        {
            Console.WriteLine("Money transferred successfully..");
        }
    }

    class Pankaja
    {
        static void Main(string[] args)
        {
            //steps to call instance method
            Light l = new Light();
            /* Light.Insta();*/
            Bank b = new Bank();
            /*l.OnButton();
            l.OffButton();*/
            b.Credit();
            b.Transfer();

        }
    }
}
