﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    //Define the ATM interface
    interface IATM
    {
        void DisplayBalance();
        void Withdraw(double amount);
        void Deposit(double amount);
    }

    //Classs ICICIAtm to implement IATM 
    class ICICIAtm : IATM
    {
        private double _balance;

        //create constructor to initialize balance
        public ICICIAtm(double initialBalance)
        {
            _balance = initialBalance;
        }

        public void DisplayBalance()
        {
            Console.WriteLine("From ICICI Bank = Your current balance is" + _balance);
        }

        public void Withdraw(double amount)
        {
            if (amount> _balance)
            {
                Console.WriteLine("From ICICI Bank :- Insufficient Balance.");
            }
            else
            {
                _balance -= amount; //It will deduct the withdrawal amount from the original balance
                Console.WriteLine("From ICICI Bank :- You have withdrawn " + amount + " & Remaining Balance is : " + _balance);
            }
        }

        public void Deposit(double amount)
        {
            _balance += amount;//Adds the deposited amount with the original balance
            Console.WriteLine("From ICICI Bank :- You have deposited " + amount + " & Remaining Balance is : " + _balance);
        }
    }

    //Classs SBIAtm to implement IATM 
    class SBIAtm : IATM
    {
        private double _balance;

        public SBIAtm(double initialBalance)
        {
            _balance = initialBalance;
        }
        public void DisplayBalance()
        {
            Console.WriteLine("From SBI Bank = Your current balance is" + _balance);
        }

        public void Withdraw(double amount)
        {
            if (amount > _balance)
            {
                Console.WriteLine("From SBI Bank :- Insufficient Balance.");
            }
            else
            {
                _balance -= amount; //It will deduct the withdrawal amount from the original balance
                Console.WriteLine("From SBI Bank :- You have withdrawn " + amount + " & Remaining Balance is : " + _balance);
            }
        }

        public void Deposit(double amount)
        {
            _balance += amount;//Adds the deposited amount with the original balance
            Console.WriteLine("From SBI Bank :- You have deposited " + amount + " & Remaining Balance is : " + _balance);
        }

    }

    //Main class
    class Program
    {
       /* static void Main(string[] args)
        {
            //create an object of each bank
            IATM iciciATM = new ICICIAtm(20000);
            IATM sbiATM = new SBIAtm(10000);

            Console.WriteLine("======================Welcome to the ATM System===================");
            Console.WriteLine("Please Select Bank : ");
            Console.WriteLine("1.ICICI  2.SBI");

            int choice = int.Parse(Console.ReadLine());

            IATM selectedATM = choice == 1 ? iciciATM : sbiATM;

            bool exit = false;

            while(!exit)
            {
                Console.WriteLine("\n Select an Option: ");
                Console.WriteLine("1. Display Balance");
                Console.WriteLine("2. Withdraw Money");
                Console.WriteLine("3. Deposit Money");
                Console.WriteLine("4. Exit...");

                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        selectedATM.DisplayBalance();
                        break;

                    case 2:
                        Console.WriteLine("Please Enter amount to withdraw : ");
                        double withdrawAmount = double.Parse(Console.ReadLine());

                        selectedATM.Withdraw(withdrawAmount);
                        break;

                    case 3: 
                        Console.WriteLine("Please Enter the amount to deposit : ");
                        double depositAmount = double.Parse(Console.ReadLine());

                        selectedATM.Deposit(depositAmount);
                        break;

                    case 4:
                        exit=true;
                        Console.WriteLine("Thanks for visiting..");
                        Console.WriteLine("Please visit again");
                        break;

                    default:
                        Console.WriteLine("Choice invalid!!");
                        Console.WriteLine("Please enter valid choice..");
                        break;
                }
            }
        }*/
    }
}
