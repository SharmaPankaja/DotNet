﻿int a = 30;
float b = 30.20f;
Console.WriteLine(a+b);