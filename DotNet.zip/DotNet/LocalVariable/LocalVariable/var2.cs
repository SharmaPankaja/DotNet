﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalVariable
{
    public class var2
    {
        static void Main(string[] args)
        {
            int c = 50;
            Console.WriteLine(c);
        }
    }
}
