﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public class Exam
    {
        public const int practicals  = 25;
        private double marks;
        public static String sname;

        /*public void per (double c,double cpp)
        {
            marks = (c+cpp+practicals)*100 / 200;
        }*/
        public void result(int marks)
        {
            if(marks>=80)
            {
                marks = marks + practicals;
                Console.WriteLine("Total Marks = "+marks+" Distinction");
            }
            else if(marks<80 || marks >= 35)
            {
                marks = marks + practicals;
                Console.WriteLine("Total Marks = " + marks + " Pass");
            }
            else
            {
                marks = marks + practicals;
                Console.WriteLine("Total Marks = " + marks + " Fail");
            }
        }

        static Exam()
        {
            sname = "Pankaja";
            Console.WriteLine("Student name : " + sname);
        }

        
    }

    class EStudent
    {
        static void Main(string[] args)
        {
            
            Exam e = new Exam();
            
            e.result(78);
        }
    }
}
