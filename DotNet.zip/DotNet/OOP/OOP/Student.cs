﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    public class Student
    {
        private int age;
        private string name;

        public int Age {
            get { 
                return age; 
            }
            set {
                if (value > 0)
                    age = value;
                else
                    Console.WriteLine("Age must be positive");
            }
        }

        public string Name 
        {
            get {
                return name; 
            }
            set {  
                name = value;
            }
        }
    }
    
    class Admission
    {
        /*static void Main(string[] args)
        {
            Student s = new Student();
            s.Name = "Pankaja";
            s.Age = 23;
            Console.WriteLine("Name is " +s.Name);
            Console.WriteLine("Age is " + s.Age);

        }*/
    }
}
