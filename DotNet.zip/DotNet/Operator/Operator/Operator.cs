﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operator
{
    public class Operator
    {
        public static void Main(string[] args)
        {
            int a = 20;
            int b = 18;
            
            if(a%2==0 && a < 50)
            {
                Console.WriteLine(a + "is an even number and in the range of 1 to 50.");
            }
            else
            {
                Console.WriteLine("Either odd number or not in range");
            }

            if(b%2==0 || b<21)
            {
                Console.WriteLine("True");
            }
            else { Console.WriteLine("False"); }
            


        }
    }
}
