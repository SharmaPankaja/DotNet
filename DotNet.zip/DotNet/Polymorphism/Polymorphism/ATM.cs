﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    abstract class Bank
    {
        public abstract void Withdraw(double amount);
        public abstract void displayBalance();
        public abstract void Deposit(double amount);
    }

    class SbiBankAtm : Bank
    {
        private double balance;

        public SbiBankAtm(double initialBal)
        {
            balance = initialBal;
        }
        public override void Withdraw(double amount)
        {
            balance -= amount;
            Console.WriteLine("Withdrawl successful..");
            Console.WriteLine("Remaining balance = " + balance);
        }

        public override void displayBalance()
        {
            Console.WriteLine("========SBI===============");
            Console.WriteLine("Total balance = "+balance);
        }

        public override void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Deposit successful..");
            Console.WriteLine("Remaining balance = " + balance);
        }

    }

    class OtherBankAtm : Bank
    {
        private double balance;

        public OtherBankAtm(double initialBal)
        {
            balance = initialBal;
        }
        public override void Withdraw(double amount)
        {
            balance -= amount;
            Console.WriteLine("Withdrawl successful..");
            Console.WriteLine("Remaining balance = " + balance);
        }

        public override void displayBalance()
        {
            Console.WriteLine("========Others===============");
            Console.WriteLine("Total balance = " + balance);
        }

        public override void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Deposit successful..");
            Console.WriteLine("Remaining balance = " + balance);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            //create an object of each bank
            SbiBankAtm sbi = new SbiBankAtm(5000);
            OtherBankAtm others = new OtherBankAtm(5000);

            Console.WriteLine("======================Welcome to the ATM System===================");
            Console.WriteLine("Please Select Bank : ");
            Console.WriteLine("1.SBI  2.Others");

            int choice = int.Parse(Console.ReadLine());

            Bank selectedATM = choice == 1 ? sbi : others;

            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n Select an Option: ");
                Console.WriteLine("1. Display Balance");
                Console.WriteLine("2. Withdraw Money");
                Console.WriteLine("3. Deposit Money");
                Console.WriteLine("4. Exit...");

                int option = int.Parse(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        selectedATM.displayBalance();
                        break;

                    case 2:
                        Console.WriteLine("Please Enter amount to withdraw : ");
                        double withdrawAmount = double.Parse(Console.ReadLine());

                        selectedATM.Withdraw(withdrawAmount);
                        break;

                    case 3:
                        Console.WriteLine("Please Enter the amount to deposit : ");
                        double depositAmount = double.Parse(Console.ReadLine());

                        selectedATM.Deposit(depositAmount);
                        break;

                    case 4:
                        exit = true;
                        Console.WriteLine("Thanks for visiting..");
                        Console.WriteLine("Please visit again");
                        break;

                    default:
                        Console.WriteLine("Choice invalid!!");
                        Console.WriteLine("Please enter valid choice..");
                        break;
                }
            }
        }
    }


}
