﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    /*class Animal
    {
        public virtual void Speak()
        {
            Console.WriteLine("Animal Speaks");
        }
    }*/

    class BookTickets
    {
        public virtual void Book()
        {
            Console.WriteLine("Tickets Booking is openend");
        }
    }

    class BookTrain : BookTickets
    {
        public override void Book()
        {
            Console.WriteLine("Booking for train..");
        }
    }

    class BookFlight : BookTickets
    {
        public override void Book()
        {
            Console.WriteLine("Booking for flight..");
        }
    }

    /*class Dog : Animal
    {
        public override void Speak()
        {
            Console.WriteLine("Dog is Barking");
        }
    }
*/
    /*class Program
    {
        static void Main(string[] args)
        {
            BookTrain bookTrain = new BookTrain();
            bookTrain.Book();
            BookFlight bookFlight = new BookFlight();   
            bookFlight.Book();
        }
    }*/
}
