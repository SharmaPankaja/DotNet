﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
     class Calculator
    {
        public int Add(int x, int y)
        {
            return x + y;
        }

        public int Add(int x, int y , int z)
        {
            return x + y + z;
        }
    }

    class calci
    {
       /* static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            Console.WriteLine( calculator.Add(21, 112));

        }*/
    }
}
