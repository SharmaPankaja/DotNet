﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
     class Password
    {
        private int defaultPass;

        public Password(int password)
        {
            defaultPass = password;
        }

        public void ChangePassword()
        {
            Console.WriteLine("Enter old password");
            int oldPassword = int.Parse(Console.ReadLine());    
            
            if(oldPassword != defaultPass)
            {
                Console.WriteLine("Password does not match..PLease enter valid password..");
            }
            else
            {
                Console.WriteLine("Enter New Password");
                int newPassword = int.Parse(Console.ReadLine());
                defaultPass = newPassword;
                Console.WriteLine("Password changed successfully..");
            }
        }
    }

    class Progarm
    {
        /*static void Main(string[] args)
        {
            Password pass = new Password(1234);
            Console.WriteLine("Enter a choice : ");
            Console.WriteLine("1.Change Password  2.Exit");
            int choice = int.Parse(Console.ReadLine());

            bool exit = false;

            while(!exit)
            {
                switch(choice)
                {
                    case 1: 
                        pass.ChangePassword();
                        break;

                    case 2: 
                        exit = true;
                        Console.WriteLine("Thanks for visiting");
                        break;

                    default:
                        Console.WriteLine("Invalid choice..Please try again..");
                        break;
                }
            }*//*
        }*/
    }
}
