﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    class Addition
    {
        public virtual void add()
        {
            Console.WriteLine("Adding");
        }
    }
    class ATM : Addition
    {
        public override void add()
        {
            int a = 34;
            int b = 34;
            Console.WriteLine("Addition = " + (a + b));
        }
    }

    /*class Program1
    {
        static void Main(string[] args) {
        Add add = new Add();
            add.add();
        }
    }*/
}
