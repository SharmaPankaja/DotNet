﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TypeCast
{
    public class Program
    {
        //const variable
        /*const double Pi = 3.14159;
        const int MaxValue = 100;
        const string Name = "Pankaja Sharma";*/
        readonly double Pi;
        readonly string Name;

        public static void Main(string[] args)
        {
            //double Pi = 3.14;
            string Name = "Pankaja";
            //double Pi = 3.14;
            //Console.WriteLine("The value of Pi is = " + Pi);
            //Console.WriteLine("The Max value is = " + MaxValue);
            Console.WriteLine("My name is = " + Name);
            //Pi = 3.14;
        }
    }
}
