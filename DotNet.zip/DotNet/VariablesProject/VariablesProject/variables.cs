﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VariablesProject
{
    
    public class variables
    {
        public static float a = 20.05f; //instance var
        static int b=20; //static var
        
        static void Main(string[] args)
        {
            int c = 20; //local var
            Console.WriteLine(a + b+c);
            
        }
    }
    
}
